//
//  ARRMRR.h
//  TestARRLayouts
//
//  Created by Patrick Beard on 3/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MRRBase.h"

@interface ARRMRR : MRRBase
@property(retain) id dataSource;
@end
