//
//  main.m
//  MyStudy
//
//  Created by apple on 2019/1/4.
//  Copyright © 2019年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <malloc/malloc.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSObject *obj = [[NSObject alloc] init];
        
        id __weak obj1 = obj;
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        
        dispatch_async(queue, ^{
            NSData * queData = [NSData dataWithContentsOfURL:[NSURL URLWithString:@"https://img.jbwl66.com/iOSAppConfig.xml"]];
           NSLog(@"queData=====%@",queData);
        });
        
        NSLog(@"一个三四");
        
    }
    return 0;
}
