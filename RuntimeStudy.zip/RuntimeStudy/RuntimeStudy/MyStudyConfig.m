//
//  MyStudyConfig.m
//  RuntimeStudy
//
//  Created by apple on 2019/1/4.
//  Copyright © 2019年 apple. All rights reserved.
//

#import "MyStudyConfig.h"

@implementation MyStudyConfig

- (instancetype)init{
    if (self = [super init]) {
        if (self.MyStudyConfigBlock) {
            self.MyStudyConfigBlock(@"12345678909876");
        }
    }
    return self;
}
@end
