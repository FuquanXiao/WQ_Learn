//
//  main.m
//  RuntimeStudy
//
//  Created by apple on 2019/1/4.
//  Copyright © 2019年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "MyStudyRuntime.h"

int main(int argc, char * argv[]) {
    
    
    
    @autoreleasepool {
        
//        NSObject *aaaaaaaaaaaaobj = [[NSObject alloc] init];
//        id __weak dddddddddddddddddobj1 = aaaaaaaaaaaaobj;
        
        void (^stackBlock)(NSString *str) = ^(NSString *str) {
            NSLog(@"%@", str);
        };
        
        
//        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
