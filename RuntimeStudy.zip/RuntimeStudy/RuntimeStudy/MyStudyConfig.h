//
//  MyStudyConfig.h
//  RuntimeStudy
//
//  Created by apple on 2019/1/4.
//  Copyright © 2019年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyStudyConfig : NSObject
@property (nonatomic,copy)void *(^MyStudyConfigBlock)(NSString *myStudyConfigName);
@end
