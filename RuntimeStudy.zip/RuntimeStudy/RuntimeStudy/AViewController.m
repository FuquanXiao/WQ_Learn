//
//  AViewController.m
//  RuntimeStudy
//
//  Created by apple on 2019/3/18.
//  Copyright © 2019 apple. All rights reserved.
//

#import "AViewController.h"

@interface AViewController ()
@property (nonatomic,copy)void (^myBlock)(void);
@end

@implementation AViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.myBlock = ^{
        [self printFA];
    };
    
}


- (void)printFA{
    NSLog(@"1234567890-");
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
