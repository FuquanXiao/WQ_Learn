//
//  MyStudyRuntime.m
//  RuntimeStudy
//
//  Created by apple on 2019/1/4.
//  Copyright © 2019年 apple. All rights reserved.
//

#import "MyStudyRuntime.h"

@interface MyStudyRuntime()

@end


@implementation MyStudyRuntime
- (instancetype)init{
    if (self = [super init]) {
        [self zzzzzzConfig];
    }
    return self;
}
- (void)zzzzzzConfig{
    
    id  aaaaaaaaaaweakObj = [NSObject new];
    
    __weak bbbbbbbweak = aaaaaaaaaaweakObj;
    
}
@end
