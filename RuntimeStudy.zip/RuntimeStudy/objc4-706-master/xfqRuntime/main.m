//
//  main.m
//  xfqRuntime
//
//  Created by xfq on 2019/4/4.
//

#import <Foundation/Foundation.h>
#import "PeoPle.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
       
        
//        NSLog(@"12345678900987654321");111
        
        PeoPle *objjjjjjj = [PeoPle new];
        
       __weak PeoPle *obj2222222 = objjjjjjj;
//        void(^MyBlockAAAA)(void) = ^{};
               __weak PeoPle *obj22222223 = objjjjjjj;

        
//      __weak  void(^MyBlockNNNNN)(void) =  MyBlockAAAA;
        
//        NSLog(@"asdfghjkl");

       PeoPle *obccccc = [[PeoPle alloc] init];
//
        obj2222222 = obccccc;
//        __weak PeoPle *  wwwwwwww = AAAAA;
//
//        NSLog(@"qwertyui");
//
//        NSLog(@"-------%@",AAAAA);
//
    }
    return 0;
}
