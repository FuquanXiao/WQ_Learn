//
//  PeoPle.m
//  xfqRuntime
//
//  Created by xfq on 2019/4/5.
//

#import "PeoPle.h"
//typedef void(^MyBlock)(void);


@interface PeoPle()


//@property (nonatomic,copy) void(^MyBlock)(void);



//(*(NSObject **)((char *)self + OBJC_IVAR_$_PeoPle$_myyyyyyyyyyObj)) = myyyyyyyyyyObj;


/**void objc_setProperty_nonatomic(id self, SEL _cmd, id newValue, ptrdiff_t offset)
{
    reallySetProperty(self, _cmd, newValue, offset, false, false, false);
}
 */
@property (nonatomic,strong)NSObject *myyyyyyyyyyObj;

//objc_setProperty (self, _cmd, __OFFSETOFIVAR__(struct PeoPle, _myyyyyyyyyyObj111), (id)myyyyyyyyyyObj111, 0, 0);

/**

 MRC 下使用retain 修饰block
 
void objc_setProperty_nonatomic(id self, SEL _cmd, id newValue, ptrdiff_t offset)
{
    reallySetProperty(self, _cmd, newValue, offset, false, false, false);
}
 
 */
@property (nonatomic,retain)NSObject *myyyyyyyyyyObj111;

//objc_setProperty (self, _cmd, __OFFSETOFIVAR__(struct PeoPle, _myyyyyyyyyyObj222), (id)myyyyyyyyyyObj222, 0, 1);

/**
 xfq:block作为属性时 使用copy或者strong  mrc strong copy
 reallySetProperty(id self, SEL _cmd, id newValue, ptrdiff_t offset, bool atomic, bool copy, bool mutableCopy)
 */
/**
void objc_setProperty_nonatomic_copy(id self, SEL _cmd, id newValue, ptrdiff_t offset)
{
    reallySetProperty(self, _cmd, newValue, offset, false, true, false);
}
*/
@property (nonatomic,copy)NSObject *myyyyyyyyyyObj222;

//(*(NSInteger *)((char *)self + OBJC_IVAR_$_PeoPle$_myyyyyyyyyyObj3333)) = myyyyyyyyyyObj3333;
@property (nonatomic,assign)NSInteger myyyyyyyyyyObj3333;

// (*(NSObject **)((char *)self + OBJC_IVAR_$_PeoPle$_myyyyyyyyyyObjObj)) = myyyyyyyyyyObjObj;
//objc_setProperty_atomic
@property (atomic,strong)NSObject *myyyyyyyyyyObjObj;


// objc_setProperty (self, _cmd, __OFFSETOFIVAR__(struct PeoPle, _myyyyyyyyyyObj22222_2222), (id)myyyyyyyyyyObj22222_2222, 1, 1);
//objc_setProperty_atomic_copy
@property (atomic,copy)NSObject *myyyyyyyyyyObj22222_2222;


@end
@implementation PeoPle
- (instancetype)init{
    if (self = [super init]) {
        
//        self.myyyyyyyyyyObj = [[NSObject alloc] init];
//        self.myyyyyyyyyyObj111 = [[NSObject alloc] init];
//        self.myyyyyyyyyyObj222 = [[NSObject alloc] init];
//        self.myyyyyyyyyyObj3333 = 111111111;
//        self.myyyyyyyyyyObjObj = [[NSObject alloc] init];
//        self.myyyyyyyyyyObj22222_2222 = [[NSObject alloc] init];
        
        
        
//        self.MyBlock =  ^{
//
//        };
//        NSLog(@"-------%@",self.MyBlock);
    }
    return self;
}


- (void)testAAAAAA{
    
    
    
   
    
//    MYAAAAAAAAAA(^{
//
//    },^{});
    
}


void MYAAAAAAAAAA(void(^dddddddd)(void),void(^fffffffff)(void)){
    NSLog(@"BBBLLLLL===%@", dddddddd);
    NSLog(@"fffffffff===%@", fffffffff);

}

@end
